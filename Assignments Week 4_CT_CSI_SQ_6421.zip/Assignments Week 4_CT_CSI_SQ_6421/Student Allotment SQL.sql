-- Step 1: Drop existing tables if they exist, starting with tables that have foreign keys
-- This ensures you don't violate foreign key constraints when dropping.

IF OBJECT_ID('Allotments', 'U') IS NOT NULL
    DROP TABLE Allotments;
GO

IF OBJECT_ID('UnallottedStudents', 'U') IS NOT NULL
    DROP TABLE UnallottedStudents;
GO

IF OBJECT_ID('StudentPreference', 'U') IS NOT NULL
    DROP TABLE StudentPreference;
GO

IF OBJECT_ID('StudentDetails', 'U') IS NOT NULL
    DROP TABLE StudentDetails;
GO

IF OBJECT_ID('SubjectDetails', 'U') IS NOT NULL
    DROP TABLE SubjectDetails;
GO

-- Step 2: Create the tables in the correct order (no foreign key dependencies first)

-- Create SubjectDetails Table
CREATE TABLE SubjectDetails (
    SubjectId VARCHAR(10) PRIMARY KEY,
    SubjectName VARCHAR(50),
    MaxSeats INT,
    RemainingSeats INT DEFAULT 0
);
GO

-- Create StudentDetails Table
CREATE TABLE StudentDetails (
    StudentId VARCHAR(10) PRIMARY KEY,
    StudentName VARCHAR(50),
    GPA DECIMAL(3, 1),
    Branch VARCHAR(10),
    Section VARCHAR(1)
);
GO

-- Create StudentPreference Table (depends on StudentDetails and SubjectDetails)
CREATE TABLE StudentPreference (
    StudentId VARCHAR(10),
    SubjectId VARCHAR(10),
    Preference INT,
    PRIMARY KEY (StudentId, SubjectId),
    FOREIGN KEY (StudentId) REFERENCES StudentDetails(StudentId),
    FOREIGN KEY (SubjectId) REFERENCES SubjectDetails(SubjectId)
);
GO

-- Create Allotments Table (depends on StudentDetails and SubjectDetails)
CREATE TABLE Allotments (
    SubjectId VARCHAR(10),
    StudentId VARCHAR(10),
    PRIMARY KEY (SubjectId, StudentId),
    FOREIGN KEY (SubjectId) REFERENCES SubjectDetails(SubjectId),
    FOREIGN KEY (StudentId) REFERENCES StudentDetails(StudentId)
);
GO

-- Create UnallottedStudents Table (depends on StudentDetails)
CREATE TABLE UnallottedStudents (
    StudentId VARCHAR(10) PRIMARY KEY,
    FOREIGN KEY (StudentId) REFERENCES StudentDetails(StudentId)
);
GO

-- Step 3: Insert sample data into the tables
-- MODIFICATION START: Reduced MaxSeats for PO1491 and PO1492 to make them fill faster.

INSERT INTO SubjectDetails (SubjectId, SubjectName, MaxSeats, RemainingSeats) VALUES
('PO1491', 'Basics of Political Science', 3, 3), -- Reduced from 60
('PO1492', 'Basics of Accounting', 1, 1),    -- Reduced from 120
('PO1493', 'Basics of Financial Markets', 90, 90),
('PO1494', 'Eco philosophy', 60, 60),
('PO1495', 'Automotive Trends', 60, 60);
GO

-- Insert sample data into StudentDetails
INSERT INTO StudentDetails (StudentId, StudentName, GPA, Branch, Section) VALUES
('159103036', 'Mohit Agarwal', 8.9, 'CCE', 'A'),
('159103037', 'Rohit Agarwal', 5.2, 'CCE', 'A'),
('159103038', 'Shohit Garg', 7.1, 'CCE', 'B'),
('159103039', 'Mrinal Malhotra', 7.9, 'CCE', 'A'),
('159103040', 'Mehreet Singh', 5.6, 'CCE', 'A'),
('159103041', 'Arjun Tehlan', 9.2, 'CCE', 'B'),
('159103042', 'New Unallotted', 4.5, 'CCE', 'C'); -- NEW STUDENT: Low GPA, will likely be unallotted
GO

-- Insert sample data into StudentPreference
INSERT INTO StudentPreference (StudentId, SubjectId, Preference) VALUES
('159103036', 'PO1491', 1),
('159103036', 'PO1492', 2),
('159103036', 'PO1493', 3),
('159103036', 'PO1494', 4),
('159103036', 'PO1495', 5),
('159103037', 'PO1491', 1),
('159103037', 'PO1492', 2),
('159103038', 'PO1493', 1),
('159103039', 'PO1491', 1),
('159103040', 'PO1492', 1),
('159103041', 'PO1491', 1),
-- NEW STUDENT PREFERENCES for 159103042. Preferences for subjects that fill up.
('159103042', 'PO1491', 1), -- Pref 1 for a popular, limited seat subject
('159103042', 'PO1492', 2), -- Pref 2 for another popular, very limited seat subject
('159103042', 'PO1493', 3),
('159103042', 'PO1494', 4),
('159103042', 'PO1495', 5);
GO

-- Step 4: Create the stored procedure (with the crucial, final correction)

-- Drop the stored procedure if it already exists to allow for re-creation
IF OBJECT_ID('AllocateSubjects', 'P') IS NOT NULL
    DROP PROCEDURE AllocateSubjects;
GO

CREATE PROCEDURE AllocateSubjects
AS
BEGIN
    -- Clear previous allotment results
    DELETE FROM Allotments;
    DELETE FROM UnallottedStudents;

    -- Create a temporary table to keep track of students who have been allotted
    CREATE TABLE #AllocatedStudents (
        StudentId VARCHAR(10) PRIMARY KEY,
        IsAllotted BIT DEFAULT 0
    );

    -- Initialize all students as not allotted
    INSERT INTO #AllocatedStudents (StudentId, IsAllotted)
    SELECT StudentId, 0 FROM StudentDetails;

    -- Loop through preferences from 1 to 5
    DECLARE @currentPreference INT = 1;
    WHILE @currentPreference <= 5
    BEGIN
        -- The temporary table #StudentsForCurrentPreference will now also store GPA
        -- The ORDER BY is NOT needed here because the cursor's SELECT will handle ordering.
        SELECT sp.StudentId, sp.SubjectId, sd.GPA -- Ensure GPA is selected into the temp table
        INTO #StudentsForCurrentPreference
        FROM StudentPreference sp
        INNER JOIN StudentDetails sd ON sp.StudentId = sd.StudentId
        INNER JOIN #AllocatedStudents als ON sp.StudentId = als.StudentId
        WHERE sp.Preference = @currentPreference AND als.IsAllotted = 0;

        -- Declare variables for cursor fetch
        DECLARE @studentId VARCHAR(10);
        DECLARE @subjectId VARCHAR(10);
        -- @studentGPA variable is not strictly needed for the fetch if only sorting by it
        -- but including it for clarity that GPA is used for ordering.
        DECLARE @fetchedGPA DECIMAL(3, 1);
        DECLARE @remainingSeats INT;

        -- CRITICAL FINAL CORRECTION: Add ORDER BY directly to the cursor's SELECT statement
        -- This ensures the students are processed in the correct GPA-descending order
        DECLARE student_cursor CURSOR LOCAL FORWARD_ONLY FOR
        SELECT StudentId, SubjectId, GPA -- Select GPA from the temp table for ordering
        FROM #StudentsForCurrentPreference
        ORDER BY GPA DESC, StudentId ASC; -- EXPLICIT ORDERING FOR THE CURSOR OPERATION

        OPEN student_cursor;
        -- Fetch into variables, including the GPA (even if not used later in the loop body)
        FETCH NEXT FROM student_cursor INTO @studentId, @subjectId, @fetchedGPA;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            -- Check if seats are available for the preferred subject
            SELECT @remainingSeats = RemainingSeats
            FROM SubjectDetails
            WHERE SubjectId = @subjectId;

            IF @remainingSeats > 0
            BEGIN
                -- Allot the student
                INSERT INTO Allotments (SubjectId, StudentId)
                VALUES (@subjectId, @studentId);

                -- Decrement remaining seats for the subject
                UPDATE SubjectDetails
                SET RemainingSeats = RemainingSeats - 1
                WHERE SubjectId = @subjectId;

                -- Mark the student as allotted in the temporary table
                UPDATE #AllocatedStudents
                SET IsAllotted = 1
                WHERE StudentId = @studentId;
            END;

            -- Fetch the next record from the cursor
            FETCH NEXT FROM student_cursor INTO @studentId, @subjectId, @fetchedGPA;
        END;

        CLOSE student_cursor;
        DEALLOCATE student_cursor;

        -- Clean up temporary table for this iteration
        IF OBJECT_ID('tempdb..#StudentsForCurrentPreference') IS NOT NULL
            DROP TABLE #StudentsForCurrentPreference;
        SET @currentPreference = @currentPreference + 1;
    END;

    -- Insert unallotted students into the UnallottedStudents table
    INSERT INTO UnallottedStudents (StudentId)
    SELECT StudentId
    FROM #AllocatedStudents
    WHERE IsAllotted = 0;

    -- Drop the temporary table
    DROP TABLE #AllocatedStudents;

END;
GO

-- Step 5: Execute the stored procedure
EXEC AllocateSubjects;
GO

-- Step 6: View the results
SELECT * FROM Allotments;
SELECT * FROM UnallottedStudents;
SELECT * FROM SubjectDetails;